/** 
*  @file main.c
*  @brief Uses student and course libraries and tests them out.
*  @author Aycan Ozdemir
*  @date 4/8/2022
*
*/

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Starting point of the program that prints all the students passing Math101 course
 * @details It enrolls 20 students in math101 and prints the students who are passing the course 
 * @return int
 * 
 */

int main()
{
  srand((unsigned) time(NULL));

  // Math101 declaring variable of type Course
  Course *MATH101 = calloc(1, sizeof(Course));

  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // For loop to enroll 20 students 
  // Random students are being generated and enrolled into Math101 course.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // declaring variable of type Student and assigning it as top student of the grade
  // variable student is pointer to pointer
  Student *student;

  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // prints total number of passing students along with their information like name
  int total_passing; 
  Student *passing_students = passing(MATH101, &total_passing); 
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");

  // loop to print all passong students
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}