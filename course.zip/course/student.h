/** 
*  @file student.h
*  @brief This is the documentation for header file for structure and function definitions
*  @details The function definitions gets implemented in student.c
*  @date 4/12/2022
*  @author Aycan Ozdemir
*
*/

/** 
 * @brief Declaration of data type structure Student
 * @details This structure is used to represent the information of a student
 * struct contains:
 * - first name of the student
 * - last name of the student
 * - student id of the student
 * - array of grades for the studet
 * - number of grades of the student
 * 
*/
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);

double average(Student *student);

void print_student(Student *student);

Student* generate_random_student(int grades); 
