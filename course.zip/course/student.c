/** 
*  @file student.c
*  @brief This is the documentation for student.c
*  @date 4/12/2022
*  @author Aycan Ozdemir
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/** 
 * @brief Helper function to add grade for a given student
 * @param[in] student - Student whose grade would be added
 * @param[in] grade - The grade that would be added
*/
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // If this is student's first grade, allocate space to store it
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  // If we already have the grade array, reallocate more space for the new grade that would be entered
  else
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/** 
 * @brief Helper function to return average for a given student
 * @param[in] student - Student whose average would be calculated and returned
 * @return double
*/
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  // loop to find total marks of the student
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/** 
 * @brief Helper function to print information of a given student
 * @param[in] student - Student whose information is to be printed
*/
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");

  // loop to print all of the student's grades
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/** 
 * @brief Helper function to generate a random student
 * @param[in] grades - number of grades that needed to be generated
 * @param[out] new_student - the random generated student
 * @return Student*
*/
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  // allocating space on heap to store the student
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // loop to assign radom student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // loop to assign random grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}