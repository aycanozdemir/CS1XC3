/** 
*  @file course.h
*  @brief This is the documentation for header file for structure and function definitions
*  @details The function definitions gets implemented in course.c
*  @date 4/12/2022
*  @author Aycan Ozdemir
*
*/

#include "student.h"
#include <stdbool.h>

/** 
 * @brief Declaration of data type structure Course
 * @details This structure is used to represent the information of a course
 * struct contains:
 * - name of the course
 * - code of the student
 * - array of students enrolled in the course
 * - number of students taking this course
 * 
*/
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


