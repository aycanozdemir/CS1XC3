/** 
*  @file course.c
*  @brief This is the documentation for course.c
*  @date 4/12/2022
*  @author Aycan Ozdemir
*
*/

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/** 
 * @brief Helper function to enroll a student in the given course
 * @details Addes the student into the array of enrolled students of the course
 * @param[in] course - The course in which the student would be enrolled
 * @param[in] student - The student that needs to be enrolled
*/
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // Allocate the space if its the first student in the course to get enrolled
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  // If the course already has students, reallocate the space to add the new student
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * @brief Helper function to print information about a given course recursively
 * @param[in] course - the course for which we need to print information
*/
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // loop to print infomrmation of all students enrolled in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * @brief Helper function that returns the student with the top average (top student)
 * @param[in] course - The course in which we are looking for top student
 * @param[out] student - The top student that gets returned
 * @return Student* 
*/
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  // loop through all the students to find the top average student
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * @brief Helper function that returns the students that are passing the given course
 * @details The function re-writes the value for the number of students passing the course
 * @param[in] course - course in which we are looking for passing students
 * @param[in] total_passing - total number of passing students in the course
 * @param[out] passing - array of passing students that gets returned
 * @return Student
*/
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // loop to calculate the number of passing students
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // allocating space enogh to accomodate all passing students
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // loops to add the passing students in the array
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}